"""Baseline example: build lag features and train RandomForest."""
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import precision_recall_curve, auc
from sqlalchemy import create_engine
import os

DB_URL = os.environ.get('DATABASE_URL','postgresql://user:pass@localhost:5432/predictive_crime')

def load_agg():
    engine = create_engine(DB_URL)
    df = pd.read_sql('SELECT * FROM daily_cell_agg ORDER BY cell_id, date', engine, parse_dates=['date'])
    return df

def train_baseline():
    df = load_agg()
    df['label_next'] = df.groupby('cell_id')['count_total'].shift(-1).fillna(0) > 0
    df['lag1'] = df.groupby('cell_id')['count_total'].shift(1).fillna(0)
    df['lag7'] = df.groupby('cell_id')['count_total'].shift(7).fillna(0)
    features = ['lag1','lag7']
    X = df[features].fillna(0)
    y = df['label_next'].astype(int)
    ts = TimeSeriesSplit(n_splits=3)
    for train_idx, test_idx in ts.split(X):
        X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
        y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
        clf = RandomForestClassifier(n_estimators=100, class_weight='balanced', random_state=42)
        clf.fit(X_train, y_train)
        probs = clf.predict_proba(X_test)[:,1]
        precision, recall, _ = precision_recall_curve(y_test, probs)
        print('AUC-PR', auc(recall, precision))
    return clf

if __name__ == '__main__':
    train_baseline()
