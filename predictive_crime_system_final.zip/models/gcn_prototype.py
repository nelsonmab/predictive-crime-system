# Prototype skeleton for a simple GCN using PyTorch Geometric.
import torch
try:
    from torch_geometric.nn import GCNConv
except Exception:
    GCNConv = None

class SimpleGCN(torch.nn.Module):
    def __init__(self, in_channels, hidden=64):
        super().__init__()
        if GCNConv is None:
            raise RuntimeError('PyG not available. Install torch-geometric to run.')
        self.conv1 = GCNConv(in_channels, hidden)
        self.conv2 = GCNConv(hidden, hidden)
        self.fc = torch.nn.Linear(hidden, 1)

    def forward(self, x, edge_index):
        x = self.conv1(x, edge_index).relu()
        x = self.conv2(x, edge_index).relu()
        return self.fc(x).squeeze()
