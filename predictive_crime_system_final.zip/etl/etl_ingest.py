"""ETL skeleton: load incidents CSV into PostGIS and aggregate into grid cells."""
import geopandas as gpd
import pandas as pd
from sqlalchemy import create_engine, text
import os

DB_URL = os.environ.get('DATABASE_URL','postgresql://user:pass@localhost:5432/predictive_crime')

def load_incidents_csv(path, source_name='csv_source'):
    df = pd.read_csv(path, parse_dates=['occurred_at'])
    gdf = gpd.GeoDataFrame(df, geometry=gpd.points_from_xy(df.lon, df.lat), crs='EPSG:4326')
    engine = create_engine(DB_URL)
    gdf.to_postgis('raw_incidents_temp', engine, if_exists='replace', index=False)
    with engine.begin() as conn:
        conn.execute(text("""
        INSERT INTO raw_incidents (source, incident_type, occurred_at, geom, raw_json)
        SELECT :source_name, incident_type, occurred_at, geom, to_jsonb(t.*)
        FROM raw_incidents_temp t;
        """), [{"source_name": source_name}])
    print('Ingest completed.')

if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        print('Usage: python etl_ingest.py <path_to_csv>')
    else:
        load_incidents_csv(sys.argv[1])
