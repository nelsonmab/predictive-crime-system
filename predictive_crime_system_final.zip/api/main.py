from fastapi import FastAPI
from pydantic import BaseModel
from typing import List, Dict
import os
app = FastAPI(title='Predictive Crime API - Skeleton')

class PredictRequest(BaseModel):
    municipio: str
    start_date: str
    hours: int = 24

@app.get('/health')
def health():
    return {'status':'ok'}

@app.post('/predict')
def predict(req: PredictRequest):
    # Skeleton response: return empty predictions
    return {'status':'ok', 'predictions': []}
