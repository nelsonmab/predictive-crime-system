# Checklist LGPD e Privacidade
- Identificar bases legais (público/privado)
- Minimização de dados: agregação por célula
- Anonimização e pseudonimização
- DPIA (Data Protection Impact Assessment)
- Controle de acesso e logs
- Contratos para fontes privadas
