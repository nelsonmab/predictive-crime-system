# Plano resumido
- 12-week plan (MVP -> pilot)
See the created project document for full details.
