# Frontend
React + Leaflet skeleton. Create app with create-react-app and place code here.
