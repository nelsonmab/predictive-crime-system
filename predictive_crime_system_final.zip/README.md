# Predictive Crime Project - Skeleton

This repository contains a skeleton for a predictive crime system (MVP).

Folders:
- infra: kubernetes / docker manifests
- etl: ETL scripts to ingest incidents into PostGIS
- models: baseline and GNN prototype
- api: FastAPI inference service
- frontend: React + Leaflet skeleton
- docs: project docs and LGPD checklist

Use this as a starting point. See docs for details.
